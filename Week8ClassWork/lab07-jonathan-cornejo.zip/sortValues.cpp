#include <iostream>
using namespace std;

void swap(int &a, int &b) {
  int temp = a;
  a = b;
  b = temp;
}

void selectionSort(int arr[], int size) {
  int minIndex, minValue;

  for (int start = 0; start < size - 1; start++) {
    minIndex = start;
    minValue = arr[start];
    for (int index = start + 1; index < size; index++) {
      if (arr[index] < minValue) {
        minValue = arr[index];
        minIndex = index;
      }
    }
    swap(arr[minIndex], arr[start]);
  }
}

void bubbleSort(int arr[], int size) {
  for (int maxElement = size - 1; maxElement > 0; maxElement--) {
    for (int i = 0; i < maxElement; i++) {
      if (arr[i] > arr[i + 1]) {
        swap(arr[i], arr[i + 1]);
      }
    }
  }
}

int main() {
  int arr1[20] = {42, 17, 88, 3,  54, 29, 71, 16, 90, 23,
                  5,  38, 65, 12, 77, 49, 34, 10, 95, 68};

  int arr2[20] = {42, 17, 88, 3,  54, 29, 71, 16, 90, 23,
                  5,  38, 65, 12, 77, 49, 34, 10, 95, 68};
  int size1 = sizeof(arr1) / sizeof(arr1[0]);
  int size2 = sizeof(arr2) / sizeof(arr2[0]);

  bubbleSort(arr1, size1);
  selectionSort(arr2, size2);

  cout << "Array is now sorted(bubbleSort): " << endl;

  for (int i = 0; i < size1; i++) {
    cout << arr1[i] << " ";
  }

  cout << endl;

  cout << "Second array sorted(selectionSort): " << endl;

  for (int i = 0; i < size2; i++) {
    cout << arr2[i] << " ";
  }
  cout << endl;
  return 0;
}
